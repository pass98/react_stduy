import React from "react";
import { useSelector } from "react-redux";
import Badge from 'react-bootstrap/Badge'
const MovieCard = ({ movie }) => {
  
  const div_styled = {
    backgroundSize: 'cover',
    backgroundImage: `url(https://www.themoviedb.org/t/p/original${movie?.backdrop_path})`,
    wdith: '300px',
    height: '200px',
  }

  const genreMovies = useSelector((state)=> state.movie.genreList);

  return (
    <div style={div_styled} className='movie-card'>
      <div className='overlay'>
        <h1>{movie.title}</h1>
        <div className="genres">
          {movie.genre_ids.map((id) => (
            <Badge bg="danger" key={id}>
              {genreMovies.find((genre) => genre.id === id).name }
            </Badge>
          ))}
        </div>
        <div className="info">
          <span>{`평점:${movie.vote_average}`}</span>
          <span>|</span>
          <span>{movie.adult ? '청불' : '청소년관람'}</span>
        </div>
      </div>
    </div>
  )
          }
export default MovieCard;